const express = require('express');
const orderRoutes = express.Router();
const {verifyToken} = require('../Helpers/verifyToken');

const {
    newOrder
} = require('../Controller/order.controller');

//ADD ORDER
orderRoutes.post('/add-order', verifyToken, newOrder);

module.exports = orderRoutes;